<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verifica si existe la sesión del carrito, si no, la crea
    if (!isset($_SESSION['carrito'])) {
        $_SESSION['carrito'] = [];
    }

    // Obtiene el ID del producto seleccionado
    $productId = $_POST['producto'];

    // Agrega el producto al carrito
    $_SESSION['carrito'][] = $productId;

    // Puedes redirigir a la página de productos o mostrar un mensaje de éxito
    header('Location: productos.php');
    exit();
}
?>
