<?php
  $products = [
      [
          'id' => 1,
          'name1' => 'tv',
          'description' => 'Descripción del Producto 1',
          'price' => 19.99,
          'image1' => 'tv.jpg',
      ],
      [
          'id' => 2,
          'name' => 'telefono',
          'description' => 'Descripción del Producto 2',
          'price' => 29.99,
          'image' => 'telefono.jpg',
      ],
      [
          'id' => 3,
          'name' => 'nevera',
          'description' => 'Descripción del Producto 2',
          'price' => 39.99,
          'image' => 'nevera.jpg',
      ],
      // Agrega más productos según sea necesario
  ];
?>

