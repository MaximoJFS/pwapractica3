<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galería de Imágenes</title>
    <style>
      body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: #f4f4f4;
      }

      h1 {
          text-align: center;
          padding: 20px;
          background-color: #333;
          color: #fff;
          margin: 0;
      }

      .gallery {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
      }

      .gallery img {
          margin: 10px;
          max-width: 100%;
          height: auto;
          border: 1px solid #ddd;
          box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      }
    </style>
</head>
<body>

    <h1>Galería de Imágenes</h1>

    <div class="gallery">
        <?php
          $directorio = 'imagenes/';

          // Obtener todas las imágenes en el directorio
          $imagenes = glob($directorio . '*.{jpg,jpeg,png,gif}', GLOB_BRACE);

          // Mostrar cada imagen en la galería
          foreach ($imagenes as $imagen) {
              echo "<img src='$imagen' alt='Imagen'>";
          }
        ?>
    </div>

</body>
</html>
