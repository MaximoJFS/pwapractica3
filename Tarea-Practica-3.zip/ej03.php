<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contador de Visitas</title>
</head>
<body style="background-color: #F5F5DC;">
    <?php
      $archivo = "archivo.txt";
      $contador = intval(trim(file_get_contents($archivo)));

      $file = fopen($archivo, "w");
      fwrite($file, $contador+1 . PHP_EOL);

      $file = fopen($archivo, "r");
      echo fgets($file);
      fclose($file);
    ?>

    <h1>Bienvenido a mi sitio web</h1>
    <p>¡Has visitado esta página!</p>

</body>
</html>