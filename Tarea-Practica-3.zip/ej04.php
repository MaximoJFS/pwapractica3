<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juego de Adivinanzas</title>
</head>
<body>

    <h1>Juego de Adivinanzas</h1>

    <?php
    // Inicializar el número aleatorio
    $numeroAleatorio = rand(1, 10);

    // Comprobar si el formulario ha sido enviado
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Obtener la suposición del usuario
        $suposicion = $_POST["suposicion"];

        // Comprobar si la suposición es correcta
        if ($suposicion == $numeroAleatorio) {
            echo "<p>¡Felicidades! ¡Adivinaste el número $numeroAleatorio!</p>";
        } else {
            echo "<p>Lo siento, esa no es la respuesta correcta. Inténtalo de nuevo.</p>";
        }
    }
    ?>

    <form method="post">
        <label for="suposicion">Adivina el número (entre 1 y 10):</label>
        <input type="number" name="suposicion" required min="1" max="10">
        <button type="submit">Adivinar</button>
    </form>

</body>
</html>


